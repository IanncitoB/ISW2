package inge2.dataflow.zeroanalysis;

/**
 * This enum represents the possible values of the zero analysis for a variable.
 */
public enum ZeroAbstractValue {

    /**
     * We don't have information about the variable.
     */
    BOTTOM("bottom"),

    /**
     * The variable is not zero.
     */
    NOT_ZERO("not-zero"),

    /**
     * The variable is zero.
     */
    ZERO("zero"),

    /**
     * The variable may be (or not) zero.
     */
    MAYBE_ZERO("maybe-zero");

    /**
     * The name of the ZeroAbstractValue.
     */
    private final String name;

    private static final ZeroAbstractValue[][] addTable = {
            {BOTTOM,    BOTTOM,     BOTTOM,     BOTTOM},
            {BOTTOM,    MAYBE_ZERO, NOT_ZERO,   MAYBE_ZERO},
            {BOTTOM,    NOT_ZERO,   ZERO,       MAYBE_ZERO},
            {BOTTOM,    MAYBE_ZERO, MAYBE_ZERO, MAYBE_ZERO}
    };

    private static final ZeroAbstractValue[][] multiplyTable = {
            {BOTTOM,    BOTTOM,     BOTTOM,     BOTTOM},
            {BOTTOM,    NOT_ZERO,   ZERO,       MAYBE_ZERO},
            {BOTTOM,    ZERO,       ZERO,       ZERO},
            {BOTTOM,    MAYBE_ZERO, ZERO,       MAYBE_ZERO}
    };

    private static final ZeroAbstractValue[][] divideTable = {
            {BOTTOM,    BOTTOM,     BOTTOM,     BOTTOM},
            {BOTTOM,    MAYBE_ZERO, BOTTOM,     MAYBE_ZERO},
            {BOTTOM,    ZERO,       BOTTOM,     ZERO},
            {BOTTOM,    MAYBE_ZERO, BOTTOM,     MAYBE_ZERO}
    };

    private static final ZeroAbstractValue[][] mergeTable = {
            {BOTTOM,    NOT_ZERO,   ZERO,       MAYBE_ZERO},
            {NOT_ZERO,  NOT_ZERO,   MAYBE_ZERO, MAYBE_ZERO},
            {ZERO,      MAYBE_ZERO, ZERO,       MAYBE_ZERO},
            {MAYBE_ZERO,MAYBE_ZERO, MAYBE_ZERO, MAYBE_ZERO}
    };

    @Override
    public String toString() {
        return this.name;
    }

    ZeroAbstractValue(String name) {
        this.name = name;
    }

    /**
     * Returns the result of the addition between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the addition.
     */
    public ZeroAbstractValue add(ZeroAbstractValue another) {
        return addTable[this.ordinal()][another.ordinal()];
    }

    /**
     * Returns the result of the division between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the division.
     */
    public ZeroAbstractValue divideBy(ZeroAbstractValue another) {
        return divideTable[this.ordinal()][another.ordinal()];
    }

    /**
     * Returns the result of the multiplication between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the multiplication.
     */
    public ZeroAbstractValue multiplyBy(ZeroAbstractValue another) {
        return multiplyTable[this.ordinal()][another.ordinal()];
    }

    /**
     * Returns the result of the subtraction between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the subtraction.
     */
    public ZeroAbstractValue subtract(ZeroAbstractValue another) {
        return addTable[this.ordinal()][another.ordinal()];
    }

    /**
     * Returns the result of the merge between this ZeroAbstractValue and another.
     * @param another the other ZeroAbstractValue.
     * @return the result of the merge.
     */
    public ZeroAbstractValue merge(ZeroAbstractValue another) {
        return mergeTable[this.ordinal()][another.ordinal()];
    }

}
