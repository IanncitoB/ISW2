#!./venv/bin/python
import multiprocessing
import random
import time
import unittest

from src.genetic_algorithm import GeneticAlgorithm


def search_impossible_seed(process_number: int):
    result = 0
    while result < 1000:
        # 71411110
        rng = random.randint(0, 1000000)
        random.seed(rng)
        print(f'[PS: {process_number}] Seed: {rng}')

        ga = GeneticAlgorithm()
        result = ga.run()
        print(f'[PS: {process_number}] Result: {result / 10}%')

    print(f'[PS: {process_number}] Found with seed: {rng}')


class TestGeneticAlgorithm(unittest.TestCase):
    def test1(self):
        # Best fitness: 0, branch coverage: 100%
        rng = 71411110
        random.seed(rng)
        print(f'Seed: {rng}')

        ga = GeneticAlgorithm()
        result = ga.run()
        self.assertEqual(result, ['hQRi%/Z&', 'CuaxF+.', ',`n|Wl', '\r<C0J', 'V|KS', '-)f6oX<zl', 'Q77hk_@Bz', 'uA=-~=w', '%0|.n', 'kHN\x0b', ':K.vr;5JO(', 'xSG|<0%ABx'])

    def test2(self):
        # Best fitness: 0, branch coverage: 100%
        rng = 23546182
        random.seed(rng)
        print(f'Seed: {rng}')

        ga = GeneticAlgorithm()
        result = ga.run()
        self.assertEqual(result, ['', 'QvUp', '*>', 'G', 'VPZ[l\t>xom', '%&+', '>qseIF', '', '0%CM', '\t+_bat849p', '%dBlN!"A('])

    def test3(self):
        # Best fitness: 0.8, branch coverage: 90%. No da True en #C5
        rng = 620026
        random.seed(rng)
        print(f'Seed: {rng}')

        ga = GeneticAlgorithm()
        result = ga.run()
        self.assertEqual(result, ['g', '0[sw>@8', 'gEG ~$g}i', '\rs%ZQ>t,', ';SxM_$1', 'w^e*Q', '[Hn(C\x0c?Fxa', 'Naj}b|9Le', 'kTmH.+Tc|=', 'BBvEz\\', 'YwfJ7aBU', '%AJm', 'K~$w)z', ''])

    def testSearchSeed(self):
        """
        Buscamos la seed para el test3, que no llegue a terminar con los parametros por defecto de GeneticAlgorithm
        """
        processes = [multiprocessing.Process(target=search_impossible_seed, args=(i,)) for i in range(6)]
        for i, p in enumerate(processes):
            print(f'Starting process {i}')
            p.start()

        while True:
            time.sleep(1)
            for p in processes:
                if not p.is_alive():
                    print(f'Process {p} finished')
                    for process_to_kill in processes:
                        process_to_kill.kill()
                return
