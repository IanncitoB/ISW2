#!./venv/bin/python
import unittest

from src.evaluate_condition import evaluate_condition


class TestEvaluateCondition(unittest.TestCase):

    def testsEq(self):
        self.assertEqual(False, evaluate_condition(1, 'Eq', 2, 1))
        self.assertEqual(True, evaluate_condition(2, "Eq", 20, 20))

    def testsNe(self):
        self.assertEqual(True, evaluate_condition(3, "Ne", 20, 10))
        self.assertEqual(False, evaluate_condition(4, "Ne", 20, 20))

    def testsLe(self):
        self.assertEqual(True, evaluate_condition(5, "Le", 10, 20))
        self.assertEqual(False, evaluate_condition(6, "Le", 20, 10))

    def testsLt(self):
        self.assertEqual(True, evaluate_condition(7, "Lt", 10, 20))
        self.assertEqual(False, evaluate_condition(8, "Lt", 20, 10))

    def testsIn(self):
        self.assertEqual(False, evaluate_condition(9, "In", 10, {}))
        self.assertEqual(False, evaluate_condition(10, "In", 10, {1: 'uno', 2: 'dos', 3: 'tres'}))
        self.assertEqual(True, evaluate_condition(11, "In", 10, {10: 'diez'}))
        self.assertEqual(True, evaluate_condition(12, "In", 10, {10: 'diez', 10: 'diez'}))
        self.assertEqual(False, evaluate_condition(13, "In", 13, {11:'once', 12:'doce', 18:'dieciocho'}))

    def testsGt(self):
        self.assertEqual(True, evaluate_condition(14, "Gt", 'b', 'a'))
        self.assertEqual(False, evaluate_condition(15, "Gt", 'a', 'b'))

    def testsGe(self):
        self.assertEqual(True, evaluate_condition(16, "Ge", 'b', 'a'))
        self.assertEqual(False, evaluate_condition(17, "Ge", 'a', 'b'))
        self.assertEqual(True, evaluate_condition(17, "Ge", 'a', 'a'))
