#!./venv/bin/python
import unittest

from src.cgi_decode import cgi_decode
from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps, get_true_distance, get_false_distance, has_reached_condition


class TestEvaluateConditionForCgiDecodeInstrumented(unittest.TestCase):
    def setUp(self):
        clear_maps()

    def testStringWithPlus(self):
        self.assertEqual(cgi_decode("Hello+World"), cgi_decode_instrumented("Hello+World"))

        self.assertTrue(has_reached_condition(1))
        self.assertTrue(has_reached_condition(2))
        self.assertTrue(has_reached_condition(3))
        self.assertFalse(has_reached_condition(4))
        self.assertFalse(has_reached_condition(5))

        self.assertEqual(0, get_true_distance(1))
        self.assertEqual(0, get_false_distance(1))
        self.assertEqual(0, get_true_distance(2))
        self.assertEqual(0, get_false_distance(2))
        self.assertEqual(35, get_true_distance(3))
        self.assertEqual(0, get_false_distance(3))

    def testEmptyString(self):
        self.assertEqual(cgi_decode(""), cgi_decode_instrumented(""))

        self.assertTrue(has_reached_condition(1))
        self.assertFalse(has_reached_condition(2))
        self.assertFalse(has_reached_condition(3))
        self.assertFalse(has_reached_condition(4))
        self.assertFalse(has_reached_condition(5))

        self.assertEqual(1, get_true_distance(1))
        self.assertEqual(0, get_false_distance(1))

    def testStringWithPercentageWhenInvalidSecond(self):
        with self.assertRaises(ValueError) as context_manager:
            cgi_decode_instrumented("%1t")
        self.assertEqual("Invalid encoding: digit low is not a hex digit", context_manager.exception.args[0])

        self.assertTrue(has_reached_condition(1))
        self.assertTrue(has_reached_condition(2))
        self.assertTrue(has_reached_condition(3))
        self.assertTrue(has_reached_condition(4))
        self.assertTrue(has_reached_condition(5))

        self.assertEqual(0, get_true_distance(1))
        self.assertEqual(3, get_false_distance(1))
        self.assertEqual(6, get_true_distance(2))
        self.assertEqual(0, get_false_distance(2))
        self.assertEqual(0, get_true_distance(3))
        self.assertEqual(1, get_false_distance(3))
        self.assertEqual(0, get_true_distance(4))
        self.assertEqual(1, get_false_distance(4))
        self.assertEqual(14, get_true_distance(5))
        self.assertEqual(0, get_false_distance(5))

    def testStringWithPercentageWhenInvalidFirst(self):
        with self.assertRaises(ValueError) as context_manager:
            cgi_decode_instrumented("%tt")
        self.assertEqual("Invalid encoding: digit high is not a hex digit", context_manager.exception.args[0])

        self.assertTrue(has_reached_condition(1))
        self.assertTrue(has_reached_condition(2))
        self.assertTrue(has_reached_condition(3))
        self.assertTrue(has_reached_condition(4))
        self.assertFalse(has_reached_condition(5))

        self.assertEqual(0, get_true_distance(1))
        self.assertEqual(3, get_false_distance(1))
        self.assertEqual(6, get_true_distance(2))
        self.assertEqual(0, get_false_distance(2))
        self.assertEqual(0, get_true_distance(3))
        self.assertEqual(1, get_false_distance(3))
        self.assertEqual(14, get_true_distance(4))
        self.assertEqual(0, get_false_distance(4))

    def testStringWithPercentageCorrect(self):
        self.assertEqual(cgi_decode("%00"), cgi_decode_instrumented("%00"))

        self.assertTrue(has_reached_condition(1))
        self.assertTrue(has_reached_condition(2))
        self.assertTrue(has_reached_condition(3))
        self.assertTrue(has_reached_condition(4))
        self.assertTrue(has_reached_condition(5))

        self.assertEqual(0, get_true_distance(1))
        self.assertEqual(0, get_false_distance(1))

        self.assertEqual(abs((ord('%') - ord('+'))), get_true_distance(2))
        self.assertEqual(0, get_false_distance(2))

        self.assertEqual(0, get_true_distance(3))
        self.assertEqual(1, get_false_distance(3))

        self.assertEqual(0, get_true_distance(4))
        self.assertEqual(1, get_false_distance(4))

        self.assertEqual(0, get_true_distance(5))
        self.assertEqual(1, get_false_distance(5))
