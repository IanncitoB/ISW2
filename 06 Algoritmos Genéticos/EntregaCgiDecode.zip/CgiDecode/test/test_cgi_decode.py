#!./venv/bin/python
import unittest

from src.cgi_decode import cgi_decode


class TestCgiDecode(unittest.TestCase):
    def testWithoutSpecialCharacters_decodedStringEqualsInputString(self):
        encoded_string = "Hello World"
        decoded_string = cgi_decode(encoded_string)
        self.assertEqual(encoded_string, decoded_string)

    def testWithPlusCharacter_decodedStringReplacesPlusCharacterWithSpace(self):
        decoded_string = cgi_decode("Hello+World")
        self.assertEqual("Hello World", decoded_string)

    def testWithPercentageCharacter_decodedStringEqualsInputString(self):
        decoded_string = cgi_decode("Hello%20World")
        self.assertEqual("Hello World", decoded_string)

    def testWithInvalidHexadecimalCharacterOnFirstPosition_raisesValueErrorOnHighDigit(self):
        with self.assertRaises(ValueError) as context_manager:
            cgi_decode("%G0")
        self.assertEqual("Invalid encoding: digit high is not a hex digit", context_manager.exception.args[0])

    def testWithInvalidHexadecimalCharacterOnSecondPosition_raisesValueErrorOnLowDigit(self):
        with self.assertRaises(ValueError) as context_manager:
            cgi_decode("Hello%2GWorld")
        self.assertEqual("Invalid encoding: digit low is not a hex digit", context_manager.exception.args[0])
