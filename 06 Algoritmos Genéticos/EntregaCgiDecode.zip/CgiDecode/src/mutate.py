import random
from random import choice, randint
from typing import List

from src.create_population import create_test_case, get_random_character


def add_character(test_case: str) -> str:
    return test_case + get_random_character()


def remove_character(test_case: str) -> str:
    point = randint(0, len(test_case)-1)
    return test_case[0:point] + test_case[point+1:]


def modify_character(test_case: str) -> str:
    return test_case.replace(choice(test_case), get_random_character(), 1)


def add_test_case(individual: List[str]) -> List[str]:
    individual.append(create_test_case())
    return individual


def remove_test_case(individual: List[str]) -> List[str]:
    individual.pop(randint(0, len(individual) - 1))
    return individual


def modify_test_case(individual: List[str]) -> List[str]:
    valid_modifications = []
    if len(__get_valid_test_cases_for_modify_character(individual)) > 0:
        valid_modifications.append(modify_character)
    if len(__get_valid_test_cases_for_remove_character(individual)) > 0:
        valid_modifications.append(remove_character)
    if len(__get_valid_test_cases_for_add_character(individual)) > 0:
        valid_modifications.append(add_character)

    modification = choice(valid_modifications)
    if modification == modify_character:
        selected_test_case = choice(__get_valid_test_cases_for_modify_character(individual))
        individual.remove(selected_test_case)
        individual.append(modification(selected_test_case))
    elif modification == remove_character:
        selected_test_case = choice(__get_valid_test_cases_for_remove_character(individual))
        individual.remove(selected_test_case)
        individual.append(modification(selected_test_case))
    elif modification == add_character:
        selected_test_case = choice(__get_valid_test_cases_for_add_character(individual))
        individual.remove(selected_test_case)
        individual.append(modification(selected_test_case))

    return individual


def mutate(individual: List[str]) -> List[str]:
    valid_mutations = []
    if len(individual) > 0:
        valid_mutations.append(modify_test_case)
    if len(individual) > 1:
        valid_mutations.append(remove_test_case)
    if len(individual) < 15:
        valid_mutations.append(add_test_case)

    selected_mutation = choice(valid_mutations)
    return selected_mutation(individual)


def __get_valid_test_cases_for_add_character(individual: List[str]) -> List[str]:
    return list(filter(lambda test_case: len(test_case) < 10, individual))


def __get_valid_test_cases_for_remove_character(individual: List[str]) -> List[str]:
    return list(filter(lambda test_case: len(test_case) > 1, individual))


def __get_valid_test_cases_for_modify_character(individual: List[str]) -> List[str]:
    return list(filter(lambda test_case: len(test_case) > 0, individual))
