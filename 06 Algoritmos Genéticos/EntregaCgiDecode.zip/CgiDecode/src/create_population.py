import random
from random import choice
from string import printable
from typing import List


def get_random_character():
    return choice(printable)


def create_test_case() -> str:
    return "".join([get_random_character() for _ in range(random.randint(0, 10))])


def create_individual() -> List[str]:
    return [create_test_case() for _ in range(random.randint(1, 15))]


def create_population(population_size) -> List[List[str]]:
    return [create_individual() for _ in range(population_size)]
