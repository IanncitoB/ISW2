from typing import List

from src.get_fitness_cgi_decode import get_fitness_cgi_decode


def evaluate_population(population: List[List[str]]) -> dict:
    fitness = {}
    for i, individual in enumerate(population):
        fitness[i] = get_fitness_cgi_decode(individual)

    return fitness
