import random
from random import randint
from typing import List, Tuple


def crossover(parent1: List[str], parent2: List[str]) -> Tuple[List[str], List[str]]:
    point = randint(1, max(len(parent1), len(parent2)))

    p1sub1 = parent1[:point]
    p1sub2 = parent1[point:]

    p2sub1 = parent2[:point]
    p2sub2 = parent2[point:]

    return (p1sub1 + p2sub2), (p2sub1 + p1sub2)
