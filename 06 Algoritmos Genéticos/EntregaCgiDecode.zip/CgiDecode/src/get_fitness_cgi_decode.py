from typing import List

from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps, has_reached_condition, get_true_distance, get_false_distance, distances_true


def get_fitness_cgi_decode(test_suite: List[str]) -> float:
    # Borro la información de branch coverage de ejecuciones anteriores
    # Recuerden que los diccionarios true_distances y false_distances son globales
    clear_maps()

    for test_case in test_suite:
        try:
            cgi_decode_instrumented(test_case)
        except:
            pass

    fitness = 0
    for condition in range(1, 6):
        if has_reached_condition(condition):
            distance_true = get_true_distance(condition)
            distance_false = get_false_distance(condition)
            fitness += distance_true / (distance_true + 1)
            fitness += distance_false / (distance_false + 1)
        else:
            fitness += 2

    return fitness
