import sys
from typing import Dict, Union

# Inicializar mappings globales
distances_true: Dict[int, int] = {}
distances_false: Dict[int, int] = {}


def update_maps(condition_num: int, d_true: int, d_false: int):
    global distances_true, distances_false

    if condition_num in distances_true.keys():
        distances_true[condition_num] = min(
            distances_true[condition_num], d_true)
    else:
        distances_true[condition_num] = d_true

    if condition_num in distances_false.keys():
        distances_false[condition_num] = min(
            distances_false[condition_num], d_false)
    else:
        distances_false[condition_num] = d_false


def clear_maps():
    global distances_true, distances_false
    distances_true.clear()
    distances_false.clear()


def get_true_distance(condition_num: int) -> Union[int, None]:
    global distances_true
    if condition_num in distances_true.keys():
        return distances_true[condition_num]
    else:
        return None


def get_false_distance(condition_num: int) -> Union[int, None]:
    global distances_false
    if condition_num in distances_false.keys():
        return distances_false[condition_num]
    else:
        return None


def has_reached_condition(condition_num: int) -> bool:
    global distances_true, distances_false
    return condition_num in distances_true.keys() or condition_num in distances_false.keys()


def hs_get_value(hs: Union[str, Dict]) -> int | list[int]:
    if isinstance(hs, int):
        return hs
    elif isinstance(hs, str):
        return ord(hs)
    else:
        return [hs_get_value(key) for key in hs.keys()]

def evaluate_condition(condition_num: int, op: str, lhs: Union[int, str, Dict], rhs: Union[int, str, Dict]) -> bool:
    lhs_value = hs_get_value(lhs)
    rhs_value = hs_get_value(rhs)

    if op == 'Eq':
        update_maps(condition_num, abs(lhs_value - rhs_value), int(lhs == rhs))
        return lhs == rhs

    elif op == 'Ne':
        update_maps(condition_num, int(lhs == rhs), abs(lhs_value - rhs_value))
        return lhs != rhs

    elif op == 'Lt':
        update_maps(condition_num, max(lhs_value - rhs_value + 1, 0), max(rhs_value - lhs_value, 0))
        return lhs_value < rhs_value

    elif op == 'Gt':
        update_maps(condition_num, max(rhs_value - lhs_value + 1, 0), max(lhs_value - rhs_value, 0))
        return lhs_value > rhs_value

    elif op == 'Le':
        update_maps(condition_num, max(lhs_value - rhs_value, 0), max(rhs_value - lhs_value + 1, 0))
        return lhs <= rhs

    elif op == 'Ge':
        update_maps(condition_num, max(rhs_value - lhs_value, 0), max(lhs_value - rhs_value + 1, 0))
        return lhs >= rhs

    elif op == 'In':
        if len(rhs_value) == 0:
            update_maps(condition_num, sys.maxsize, 0)
        else:
            update_maps(condition_num, min([abs(lhs_value - val) for val in rhs_value]), int(lhs_value in rhs_value))

        return lhs_value in rhs_value

    else:
        raise ValueError('Operation not supported')
