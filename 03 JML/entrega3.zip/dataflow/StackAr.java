package inge2.dataflow;

public class StackAr {
    //@ public invariant -1 <= top && top < elems.length;

    /**
     * Capacidad por defecto de la pila.
     */
    private final static int DEFAULT_CAPACITY = 10;

    /**
     * Arreglo que contiene los elementos de la pila.
     */
    //@ spec_public
    private final int[] elems;

    /**
     * Indice del tope de la pila.
     */
    //@ spec_public
    private int top = -1;

    public StackAr() {
        this(DEFAULT_CAPACITY);
    }

    //@ requires capacity >= 0;
    //@ ensures this.isEmpty();
    public StackAr(int capacity) {
        elems = new int[capacity];
    }

    //@ ensures \result == (top == -1);
    //@ pure
    public boolean isEmpty() {
        return top == -1;
    }

    //@ ensures \result == (elems.length == this.size());
    //@ pure
    public boolean isFull() {
        return elems.length == top + 1;
    }

    //@ ensures \result == top + 1;
    //@ pure
    public int size() {
        return top + 1;
    }

    //@ requires !this.isFull();
    //@ ensures this.size() == \old(this.size()) + 1;
    //@ ensures elems[top] == o;
    public void push(int o) {
        assert !isFull();
        elems[++top] = o;
    }

    //@ requires !this.isEmpty();
    //@ ensures \result == \old(this.peek());
    //@ ensures this.size() == \old(this.size()) - 1;
    public int pop() {
        assert !isEmpty();
        return elems[top--];
    }

    //@ requires !this.isEmpty();
    //@ ensures \result == elems[top];
    //@ pure
    public int peek() {
        assert !isEmpty();
        return elems[top];
    }
}

