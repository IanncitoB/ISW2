package inge2.dataflow;

public class Constante {

    // Devuelve el valor constante 42.
    //
    //@ ensures \result == 42;
    public static int laConstante() {
        return 42;
    }
}