## Ejercicio 5

b) 100%

## Ejercicio 6

b) 100% ya que el branch coverage es por linea y no por iteracion
