import os

from src.utils import get_result_and_model

if __name__ == '__main__':
    # ejecuta cada .smt de cada ej de la carpeta parte_2
    for ej in [5, 6, 7]:
        print(f'* Corriendo archivos para el ej {ej}')

        for file in sorted(filter(lambda f: '.smt' in f, os.listdir(f'parte_2/ejercicio_{ej}'))):
            print(f'*** Corriendo {file} del ej {ej}')

            result, model = get_result_and_model(f"parte_2/ejercicio_{ej}/{file}")

            print("Resultado: ", result)

            if model:
                print("Modelo: ", model)
            print()

        print('--------------------------------------------------------------------------')
